#!/bin/sh
# needs: ./dump_core (arm64), JDK, ANDROID_HOME with build-tools + platform. out: rtdumper.apk
set -e
BT=$(ls -d "$ANDROID_HOME"/build-tools/* | sort -V | tail -1)
AJ=$(ls -d "$ANDROID_HOME"/platforms/android-* | sort -V | tail -1)/android.jar
rm -rf build && mkdir -p build/classes build/assets build/res-compiled
cp dump_core build/assets/dump_core
"$BT/aapt2" compile --dir android/res -o build/res-compiled
"$BT/aapt2" link -o build/base.apk -I "$AJ" --manifest android/AndroidManifest.xml \
  --min-sdk-version 26 --target-sdk-version 33 --version-code 1 --version-name 1 -A build/assets \
  -R build/res-compiled/*.flat
javac -encoding UTF-8 -source 8 -target 8 -Xlint:-options -cp "$AJ" -d build/classes $(find android/java -name '*.java')
"$BT/d8" --release --min-api 26 --lib "$AJ" --output build $(find build/classes -name '*.class')
(cd build && zip -q base.apk classes.dex)
"$BT/zipalign" -f -p 4 build/base.apk build/aligned.apk
keytool -genkeypair -keystore build/dbg.jks -storepass android -keypass android -alias k -keyalg RSA -keysize 2048 -validity 10000 -dname "CN=rd" >/dev/null 2>&1
"$BT/apksigner" sign --ks build/dbg.jks --ks-pass pass:android --key-pass pass:android --out rtdumper.apk build/aligned.apk
echo "ok -> rtdumper.apk"
